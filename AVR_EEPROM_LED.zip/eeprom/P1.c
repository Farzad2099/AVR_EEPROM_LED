#include <mega32.h>
#include <delay.h>
#include <eeprom.h>

eeprom unsigned char a;

void main(void)
{
    unsigned char x;

    DDRA = 0x00;
    DDRB = 0xFF;
    DDRD = 0x00;
    PORTD = 0x00;   

    while (1)
    {
        if (PIND.0 == 0)   
        {
            delay_ms(20);
            if (PIND.0 == 0)
            {
                x = PINA;
                a = x;
                while (PIND.0 == 0);
                delay_ms(20);
            }
        }

        if (PIND.0 == 1)   
        {
           
            PORTB = a;
        }
    }
}