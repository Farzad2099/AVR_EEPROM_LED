/*
 * P2.c
 *
 * Created: 6/1/2026 1:19:30 PM
 * Author: Farzad
 */

#include <io.h>
#include <delay.h>


void main(void)
{
   unsigned char x,y,z;
   DDRA=0xff;
   DDRD=0xff;
   DDRB=0xff;
   PORTA=0xff;
   PORTB=0x01;
   PORTD=0x00;
   x=PORTB;
   y=PORTD;
   z=PORTA;
while (1){ 
     
     PORTB=x;
     x=x<<1;
     if(PORTB==0x00)
     x=0x01;
     //------------------------------------
     PORTD=y; 
     y = (y<<1) | 0x01;
     if(PORTD==0xff)
      y=0x00;
     //------------------------------------
     PORTA=z;
     z=z<<1;
     if(PORTA==0x00)
     z=0xff;
      
     
     delay_ms(50);
    }
}
